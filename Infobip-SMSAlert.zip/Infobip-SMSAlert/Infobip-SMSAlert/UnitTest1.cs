﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OneApi.Config;
using System.Configuration;
using OneApi.Client.Impl;
using OneApi.Model;
using System.Net;
using System.Text;
using System.Collections.Generic;
using Infobip_SMSAlert.Helpers;
using System.IO;

namespace Infobip_SMSAlert
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            string[] to = new string[2] { "63923232332", "63923232332" };
            SendMessage(to, "Test message.");
        }


        public void SendMessage(string[] destinationAddress, string message)
        {
            OneApi.Config.Configuration config = new OneApi.Config.Configuration(ConfigurationManager.AppSettings["Username"].ToString(),
                ConfigurationManager.AppSettings["Password"].ToString());

            SMSClient smsClient = new SMSClient(config);

            SMSRequest smsRequest = new SMSRequest("username", message, destinationAddress);
            smsRequest.Language = new OneApi.Language(OneApi.LanguageCode.Default);

            var result = smsClient.SmsMessagingClient.SendSMS(smsRequest);
        }

        public void SendScheduledMessage(List<string> destinationAddress, string message, string schedule)
        {
            string username = ConfigurationManager.AppSettings["Username"].ToString(),
                password = ConfigurationManager.AppSettings["Password"].ToString();

            string encryptedCredentials = EncryptCredential(username, password);

            var httpWebRequest = (HttpWebRequest)WebRequest.Create("http://api.infobip.com/sms/1/text/advanced");
            httpWebRequest.Method = "POST";
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Accept = "application/json";
            httpWebRequest.Headers["authorization"] = "Basic " + encryptedCredentials;

            List<Destination> destinations = new List<Destination>();
            foreach (var number in destinationAddress)
                destinations.Add(new Destination() { to = number });

            Message textMessage = new Message()
            {
                from = username,
                destinations = destinations,
                sendAt = schedule,
                text = message
            };

            List<Message> messages = new List<Message>();
            messages.Add(textMessage);

            //JSON POST REQUEST

            JsonRequest jsonRequest = new JsonRequest() { messages = messages };
            string jsonString = JsonHelper.JsonSerializer<JsonRequest>(jsonRequest);

            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                streamWriter.Write(jsonString);
                streamWriter.Flush();
                streamWriter.Close();
            }

            //JSON GET RESPONSE

            var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
                var response = JsonHelper.JsonDeserialize<JsonResponse>(result);
            }
        }

        private string EncryptCredential(string username, string password)
        {
            string credentials = username + ":" + password;
            byte[] credentialsAsBytes = Encoding.UTF8.GetBytes(credentials);
            return Convert.ToBase64String(credentialsAsBytes).Trim();
        }
    }
}
