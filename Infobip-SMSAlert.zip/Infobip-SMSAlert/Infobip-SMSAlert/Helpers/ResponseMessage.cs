﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infobip_SMSAlert.Helpers
{
    public class ResponseMessage
    {
        public string to { get; set; }
        public Status status { get; set; }
        public string messageId { get; set; }
    }
}
