﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infobip_SMSAlert.Helpers
{
    public class Destination
    {
        public string to { get; set; }
    }
}
