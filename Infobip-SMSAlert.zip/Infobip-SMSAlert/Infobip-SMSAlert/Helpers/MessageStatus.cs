﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infobip_SMSAlert.Helpers
{
    public class MessageStatus
    {
        public string bulkId { get; set; }
        public string status { get; set; }
    }
}
